export class UsuarioAutenticarModel {
    user: string;
    tipoDoc: string;
    dni: string;
    telefono: string;
    email: string;
    persona: string;
}
