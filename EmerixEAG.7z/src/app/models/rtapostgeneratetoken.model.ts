export interface RtapostGeneraTetokenModel {
  ErrorCode: number;
  ErrorMessage: string;
  IsSent: boolean;
  MessageSent: string;
}
