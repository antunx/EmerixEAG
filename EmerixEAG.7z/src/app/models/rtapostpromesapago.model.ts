export interface rtaPostPromesaPago {
  ErrorCode: number;
  ErrorMessage: string;
  Id: number;
}
