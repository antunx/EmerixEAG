export interface RtagetDebtFreeModel {
  ErrorCode: number;
  ErrorMessage: string;
  ComprobanteJSON: string;
}
