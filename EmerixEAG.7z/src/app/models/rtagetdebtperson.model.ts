export interface RtagetDebtPersonModel {
  ErrorCode: number;
  ErrorMessage: string;
  Name: string;
  LastName: string;
  FullName: string;
  TotalDebt: number;
  DaysDebt: number;
  CountProductDebt: number;
}
