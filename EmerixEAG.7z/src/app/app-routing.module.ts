import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AuthLoginGuard } from './guards/auth-login.guard';
import { AuthGeneralGuard } from './guards/auth-general.guard';

import { LoginComponent } from './components/login/login.component';

const routes: Routes = [
  { path: 'login', component: LoginComponent },

  { path: '**', pathMatch: 'full', redirectTo: 'login' }
];
/*
const routes: Routes = [
  {
    path: `home`, loadChildren: () =>
      import('./components/home/home.module').then(m => m.HomeModule)
  },
  { path: 'login', component: LoginComponent },
  { path: ``, redirectTo: `login`, pathMatch: `full` },
  { path: '**', pathMatch: 'full', redirectTo: 'login' }
];
*/
@NgModule({
  imports: [RouterModule.forRoot(routes, { useHash: true })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
