import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login-header',
  templateUrl: './login-header.component.html'
})
export class LoginHeaderComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
