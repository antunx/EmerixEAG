export interface StandardPost {
  ErrorCode: number;
  ErrorMessage: string;
  Mensaje: string;
}
